import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  // Array need to be intitialize
  // Syntax  to define array :
  // Array_name  : { Property of arrays } [] = [];<= // uasing this way can intitialize the array  
  items: { name: string, price: string, desc: string } [] = [];
  Quantity = 1; // initialize the Property
  constructor(){
    // Need to push array items 
    this.items.push({name:'Mobiles', price: '10,000', desc: 'Mobile description'});
  }

  updateItems(itemAdded :{ name: string, price: string, desc: string }) {
    this.items.push(itemAdded);
  }

  removeDataCardItems(cardId){
    console.log(cardId);
  this.items.splice(cardId,1);
}

 /*ng-content under method*/
 onRemove(dataCardId){
    this.removeDataCardItems(dataCardId);
  }

/*onchnages hooks trigger after old value chnage into new value*/
onsubmits(){
  this.Quantity += 2;
}

}
