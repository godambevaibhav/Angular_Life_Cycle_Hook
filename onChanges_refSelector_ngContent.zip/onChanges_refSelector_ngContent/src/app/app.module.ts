import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ItemCardListComponent } from './item-card-list/item-card-list.component';

@NgModule({
  declarations: [
    AppComponent,
    AddItemComponent,
    ItemCardListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
